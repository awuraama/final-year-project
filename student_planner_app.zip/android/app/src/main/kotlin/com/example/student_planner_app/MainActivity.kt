package com.example.student_planner_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
